/* ==========================================================
   CÁLCULOS: Jornada ordinaria (Lun a Vie)
   - Jornada diaria  = (mañana_fin - mañana_ini) + (tarde_fin - tarde_ini)
   - Totales semanales: suma de Lun..Vie
   - Colación se define por selección fija (no por diferencia horaria)
   ========================================================== */

(function (global) {

  // ===== Helpers =====
  function pad2(n) { return String(n).padStart(2, "0"); }

  function hhmmToMinutes(hh, mm) {
    const h = parseInt(hh, 10) || 0;
    const m = parseInt(mm, 10) || 0;
    return h * 60 + m;
  }

  function minutesToHHMM(totalMin) {
    totalMin = Math.max(0, Math.round(totalMin));
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    return `${pad2(h)}:${pad2(m)}`;
  }

  function isZeroTime(hh, mm) {
    return (String(hh) === "00" && String(mm) === "00");
  }

  // Lee un tiempo desde los <select> por name:  lun_man_ini_h / lun_man_ini_m ...
  function getTimeFromSelects(tbody, prefix, bloque, tipo) {
    const selH = tbody.querySelector(`select[name="${prefix}_${bloque}_${tipo}_h"]`);
    const selM = tbody.querySelector(`select[name="${prefix}_${bloque}_${tipo}_m"]`);
    if (!selH || !selM) return null;

    const hh = selH.value;
    const mm = selM.value;

    // Si está en 00:00 lo consideramos "no marcado"
    if (isZeroTime(hh, mm)) return null;

    return { hh, mm, min: hhmmToMinutes(hh, mm) };
  }

  function diffMinutes(t1, t2) {
    // t2 - t1 (minutos), nunca negativo
    if (!t1 || !t2) return 0;
    return Math.max(0, t2.min - t1.min);
  }

  // ===== Cálculo por día =====
  function calcDayJornada(tbody, prefix) {
    const manIni = getTimeFromSelects(tbody, prefix, "man", "ini");
    const manFin = getTimeFromSelects(tbody, prefix, "man", "fin");
    const tarIni = getTimeFromSelects(tbody, prefix, "tar", "ini");
    const tarFin = getTimeFromSelects(tbody, prefix, "tar", "fin");

    const durMan = diffMinutes(manIni, manFin);
    const durTar = diffMinutes(tarIni, tarFin);

    // Jornada = suma de bloques trabajados (NO incluye colación)
    const jornada = durMan + durTar;
    return jornada;
  }

  // ===== Cálculo semana =====
  function calcWeekJornada(tbody, dayPrefixes) {
    let jornadaTotal = 0;

    for (const p of dayPrefixes) {
      jornadaTotal += calcDayJornada(tbody, p);
    }

    return jornadaTotal;
  }

  // ===== Pintar resumen =====
  function setJornadaLegalMessage(msgEl, text) {
    msgEl.textContent = text;
  }

  function updateHorarioEqualWarningUI(tbody, dayPrefixes) {
    const msgEl = document.getElementById("horarioIgualMsg");
    if (!msgEl) return;

    let hasEqual = false;
    for (const p of dayPrefixes) {
      for (const bloque of ["man", "tar"]) {
        const iniH = tbody.querySelector(`select[name="${p}_${bloque}_ini_h"]`);
        const iniM = tbody.querySelector(`select[name="${p}_${bloque}_ini_m"]`);
        const finH = tbody.querySelector(`select[name="${p}_${bloque}_fin_h"]`);
        const finM = tbody.querySelector(`select[name="${p}_${bloque}_fin_m"]`);
        if (!iniH || !iniM || !finH || !finM) continue;

        const iniMin = hhmmToMinutes(iniH.value, iniM.value);
        const finMin = hhmmToMinutes(finH.value, finM.value);
        const iniZero = isZeroTime(iniH.value, iniM.value);
        const finZero = isZeroTime(finH.value, finM.value);

        if (!iniZero && !finZero && iniMin === finMin) {
          hasEqual = true;
          break;
        }
      }
      if (hasEqual) break;
    }

    msgEl.classList.toggle("is-hidden", !hasEqual);
  }

  function updateJornadaLegalUI(jornadaTotalMin) {
    const msgEl = document.getElementById("jornadaLegalMsg");
    if (!msgEl) return;

    const LIMITE_MIN = 40 * 60; // 40:00
    msgEl.classList.remove("is-low", "is-ok", "is-over");

    if (jornadaTotalMin <= 0) {
      msgEl.classList.add("is-hidden");
      return;
    }

    msgEl.classList.remove("is-hidden");

    if (jornadaTotalMin < LIMITE_MIN) {
      setJornadaLegalMessage(msgEl, "Está bajo las 40 horas legales (Ley 21.561).");
      msgEl.classList.add("is-low");
      return;
    }

    if (jornadaTotalMin === LIMITE_MIN) {
      setJornadaLegalMessage(msgEl, "Cumple con las horas laborales legales.");
      msgEl.classList.add("is-ok");
      return;
    }

    setJornadaLegalMessage(msgEl, "No cumple con las 40:00 horas laborales.");
    msgEl.classList.add("is-over");
  }

  function updateResumenJornadaUI(jornadaTotalMin) {
    const elJorCro = document.getElementById("sumJornadaCro");

    if (elJorCro) elJorCro.textContent = minutesToHHMM(jornadaTotalMin);
    if (typeof global.recalcularNoLectivas === "function") {
      global.recalcularNoLectivas();
    }
    updateJornadaLegalUI(jornadaTotalMin);
  }

  /**
   * Activa el recálculo automático al cambiar cualquier select del horario.
   * @param {Object} opts
   * @param {string} opts.tbodySelector
   * @param {string[]} opts.dayPrefixes  ["lun","mar","mie","jue","vie"]
   */
  function bindRecalculoHorario(opts) {
    const tbody = document.querySelector(opts.tbodySelector || "#tbodyHorario");
    const dayPrefixes = Array.isArray(opts.dayPrefixes) ? opts.dayPrefixes : [];
    if (!tbody || dayPrefixes.length === 0) return;

    // recalcula y pinta
    function recompute() {
      const jornadaTotal = calcWeekJornada(tbody, dayPrefixes);
      updateResumenJornadaUI(jornadaTotal);
      updateHorarioEqualWarningUI(tbody, dayPrefixes);
    }

    // 1) Inicial
    recompute();

    // 2) Cada cambio
    tbody.addEventListener("change", function () {
      recompute();
    });
  }

  function bindColacionFija() {
    const select = document.getElementById("sumColacionSelect");
    const elColMin = document.getElementById("sumColacionMin");
    const elColHH = document.getElementById("sumColacionHHMM");
    if (!select || !elColMin) return;

    function updateFromSelect() {
      if (!select.value) {
        elColMin.textContent = "0";
        if (elColHH) {
          elColHH.textContent = minutesToHHMM(0);
        }
        return;
      }

      const selected = select.options[select.selectedIndex];
      const minutosAttr = selected ? selected.getAttribute("data-minutos") : null;
      const minutos = parseInt(minutosAttr, 10) || 0;
      elColMin.textContent = String(Math.max(0, minutos));
      if (elColHH) {
        elColHH.textContent = minutesToHHMM(minutos);
      }
    }

    updateFromSelect();
    select.addEventListener("change", updateFromSelect);
  }




  

  // Exponer
  global.bindRecalculoHorario = bindRecalculoHorario;
  global.bindColacionFija = bindColacionFija;

})(window);





